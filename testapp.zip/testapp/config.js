var hostUrl = "http://localhost";

var dbList = [
    {"dbService":"db", "idField":"id"},
    {"dbService":"mongo", "idField":"_id"},
    //{"dbService":"mongo", "idField":"_id", "idType": "string", "generateIds": true},
    //{"dbService":"mongo", "idField":"_id", "idType": "int", "generateIds": true},
    //{"dbService":"dynamodb", "idField":"id", "idType": "string", "generateIds": true},
    //{"dbService":"simpledb", "idField":"id", "idType": "string", "generateIds": true},
    //{"dbService":"azuretables", "idField":"RowKey", "idType": "string", "generateIds": true}
];