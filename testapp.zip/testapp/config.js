var hostUrl = "http://192.168.1.40";

var dbList = [

    //{"dbService":"db", "idField":"id", "testRelated":true},
    {"dbService":"oracle", "idField":"id", "idType": "int", "generateIds": true, "testRelated":true},
    //{"dbService":"remote", "idField":"id", "testRelated":true},
    //{"dbService":"sqlsrv_atl", "idField":"id", "testRelated":true},
    //{"dbService":"mongo", "idField":"_id"},
    //{"dbService":"mongo", "idField":"_id", "idType": "string", "generateIds": true},
    //{"dbService":"mongo", "idField":"_id", "idType": "int", "generateIds": true},
    //{"dbService":"dynamodb", "idField":"id", "idType": "string", "generateIds": true},
    //{"dbService":"simpledb", "idField":"id", "idType": "string", "generateIds": true},
    //{"dbService":"azuretables", "idField":"RowKey", "idType": "string", "generateIds": true}
];