var hostUrl = "http://localhost";
var dbInfo = {"idField":"id", "dbService":"db", "schemaService":"schema"};
// var dbInfo = {"idField":"_id", "dbService":"mongo", "schemaService":"mongo"};
// var dbInfo = {"idField":"_id", "dbService":"mongo", "schemaService":"mongo", "generateIds": true, "idType": "string"};
// var dbInfo = {"idField":"_id", "dbService":"mongo", "schemaService":"mongo", "generateIds": true, "idType": "int"};
// var dbInfo = {"idField":"id", "dbService":"dynamodb", "schemaService":"dynamodb", "generateIds": true, "idType": "string"};
// var dbInfo = {"idField":"id", "dbService":"simpledb", "schemaService":"simpledb", "generateIds": true, "idType": "string"};
// var dbInfo = {"idField":"RowKey", "dbService":"azuretables", "schemaService":"azuretables", "generateIds": true, "idType": "string"};