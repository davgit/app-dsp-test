var hostUrl = "http://localhost";
var dbInfo = {"idField":"id", "dbService":"db", "schemaService":"schema"};
//var dbInfo = {"idField":"_id", "dbService":"mongo", "schemaService":"mongo"};
